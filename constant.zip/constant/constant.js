module.exports = 
{
    kResultOk: 'ok',
    kResultNok: 'nok',
    apiUrl :  "http://127.0.0.1/api/v1/",
    NOT_CONNECT_NETWORK : 'NOT_CONNECT_NETWORK' ,
    NETWORK_CONNECTION_MESSAGE : 'Cannot connect to server, Please try again.' 
}

